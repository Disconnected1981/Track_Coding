public class KarelProgram extends Karel
{
    public void run()
    {
        for (int i = 0; i < 2; i++) {
            move();
        }
        if (notFacingNorth()) {
            turnLeft();
        }    
        move();
        putBall();
        for (int i = 0; i < 1; i++) {
            move();
        }
        for (int i = 0; i < 2; i++) {
            putBall();
        }
        turnLeft();
        for (int i = 0; i < 2; i++) {
            move();
        }    
        if (notFacingWest()) {
            turnLeft();
        }    
    }

// Methode, um Karel nach rechts zu drehen
    public void turnRight()
    {
        // Karel dreht sich nach rechts, indem er dreimal nach links dreht
        for (int i = 0; i < 3; i++) {
            turnLeft();
        }
    }
    
// Methode, um Karel um 180 Grad zu drehen
    public void turnAround()
    {
        // Karel dreht sich um 180 Grad, indem er zweimal nach links dreht
        for (int i = 0; i < 2; i++) {
            turnLeft();
        }
    }

}