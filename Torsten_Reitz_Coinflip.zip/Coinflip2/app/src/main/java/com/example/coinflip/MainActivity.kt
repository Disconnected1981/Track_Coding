package com.example.coinflip

import android.os.Bundle
import android.os.PersistableBundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import kotlin.random.Random

class MainActivity : AppCompatActivity() {
    private lateinit var imageView: ImageView
    private lateinit var textView: TextView
    private lateinit var button: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        textView = findViewById(R.id.textView)
        imageView = findViewById(R.id.imageView)
        button = findViewById(R.id.button)

        button.setOnClickListener {
            startAnimation()
        }
    }

    private fun showResult() {
        if (Random.nextBoolean()) {
            textView.text = "Zahl!"
            imageView.setImageResource(R.drawable.zahl)
        } else
            textView.text = "Kopf!"
        imageView.setImageResource(R.drawable.kopf)
    }

    private fun startAnimation() {
        val animation = imageView.animate()
        animation.duration = 1000
        animation.withEndAction {
            showResult()
        }
        animation.rotationYBy(5 * 360f)
    }
}



